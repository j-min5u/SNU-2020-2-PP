package pp202002.hw3

/*
  Exercise 3: Enigma machine

  Implement Enigma machine described below.

  Enigma machine is encryption system used by Nazi Germany during World War II
  Alan Turing, the father of Computer Science, is famous for his development of Enigma-deciphering machine.

  Enigma machine encrypts an alphabet by the connections and arrangements of internal optical wires.
  The connection of the optical wire is composed of 3 'Rotors' and a single 'Reflector'.
  The overall encoding path is shown as below.
                  +++++++++++         +++++++++++         +++++++++++        ===
  input:  'A' --> |         | --'C'-> |         | --'D'-> |         | --'F'----+\
                  | Rotor 1 |         | Rotor 2 |         | Rotor 3 |          | |  Reflector
  output: 'B' <-- |         | <-'E'-- |         | <-'S'-- |         | <-'S'----+/
                  +++++++++++         +++++++++++         +++++++++++        ===
  Each Rotor and Reflector has internal optical 'Wire's. The wire maps each alphabet to another alphabet, e.g., 'A' to 'F'.
  At first, the input alphabet goes forward through the wires of three rotors, and 'reflected' by the reflector.
  Reflector maps an alphabet to another alphabet, and vice versa, e.g. 'A' to 'F', and 'F' to 'A'

  Because of the reflector, decoding path of Enigma is just reversal of the encoding path.
                  +++++++++++         +++++++++++         +++++++++++        ===
  output: 'A' <-- |         | <-'C'-- |         | <-'D'-- |         | <-'F'----+\
                  | Rotor 1 |         | Rotor 2 |         | Rotor 3 |          | |  Reflector
  input:  'B' --> |         | --'E'-> |         | --'S'-> |         | --'S'----+/
                  +++++++++++         +++++++++++         +++++++++++        ===

  Before the first input enters, the first rotor 'rotates' one tick, that means, the internal wire is entirely rotated by 1/26 round counterclockwise.
  The effect of rotations can be decomposed into two events, 1) rotating the whole connection, 2) and shifting left by one alphabet.
  If the first rotor has turned full circle, the seconds rotor rotates one tick, and so on.

  e.g.) Suppose that the first rotor initially maps 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' to 'QWERTYUIOPASDFGHJKLZXCVBNM'
        When we type first letter, the first rotor maps 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' to 'VDQSXTHNOZRCEFGIJKYWBUAMLP',
        so if we typed 'B', it would be encrypted into 'D'.
        (rotation of wire shifts the connections into 'WERTYUIOPASDFGHJKLZXCVBNMQ', then its output is shifted left,
         that makes the map to 'VDQSXTHNOZRCEFGIJKYWBUAMLP')

  Our Enigma machine uses 1 to 5 rotors and a single reflector.
  (We will not use a plugboard)

  EnigmaSettings contains a list of initial rotor settings and reflector settings.
  You should implement the backward path of wires, and the full encryption and decryption paths of Enigma machine.

  The input will be restricted to upper cased alphabets. ('A'-'Z')

  reference links:
  https://en.wikipedia.org/wiki/Enigma_rotor_details
  https://www.theguardian.com/technology/2014/nov/14/how-did-enigma-machine-work-imitation-game
  https://hackaday.com/2017/08/22/the-enigma-enigma-how-the-enigma-machine-worked/
  https://www.youtube.com/watch?v=QwQVMqfoB2E

  P.S.) As we ignore turnover notch positions and plugboard, our Enigma machine behaves 
        slightly differently than most of the web implementations of Enigma machine.
 */

/** The initial setting of Enigma machine
 *
 * We guarantee that the connection of reflectorState is involutive,
 * that means, forall x, reflectorState.forward(reflectorState.forward(x)) == x
 *
 * @param rotorState     The internal wire connections of each Rotor. The first object of the list should be the first rotor.
 * @param reflectorState The internal wire connection of Reflector.
 */
case class EnigmaSettings(rotorState: List[Wire], reflectorState: Wire)

object Enigma extends CipherGen[EnigmaSettings] {
  def buildEncryptor(initSetting: EnigmaSettings): Enigma = new Enigma(initSetting.rotorState,initSetting.reflectorState,Nil,true)

  def buildDecryptor(initSetting: EnigmaSettings): Enigma = new Enigma(initSetting.rotorState,initSetting.reflectorState,Nil,true)
}

class Enigma(val rotState:List[Wire],val refState:Wire,val turnedinf:List[Int],val sig:Boolean) extends Encryptor with Decryptor {
  def encrypt(c: Char): (Char, Enigma) = {
    rotState match{
      case Nil=>{
        (Reflector(refState).forward(c),new Enigma(Nil,refState,Nil,true))
      }
      case hd::tl=>{
        val turns:(Int,List[Int])=turnedinf match{
          case Nil=>(0,Nil)
          case hd::tl=>(hd,tl)
        }
        if(sig){
          val t=if (turns._1<25) turns._1+1 else 0

          val turnedw:Wire=Rotor(hd).rotate()
          val t1=Rotor(turnedw).forward(c)
          val t2=if(t==0) new Enigma(tl,refState,turns._2,true).encrypt(t1) else new Enigma(tl,refState,turns._2,false).encrypt(t1)
          (Rotor(turnedw).backward(t2._1),new Enigma(turnedw::t2._2.rotState,refState,t::t2._2.turnedinf,true))
        }
        else{
          val t1=Rotor(hd).forward(c)
          val t2=new Enigma(tl,refState,turns._2,false).encrypt(t1)
          (Rotor(hd).backward(t2._1),new Enigma(hd::t2._2.rotState,refState,turns._1::t2._2.turnedinf,true))
        }

      }
    }

  }

  // Decryption of Enigma machine is same to the Encryption
  def decrypt(c: Char): (Char, Enigma) = encrypt(c)
}

sealed abstract class EnigmaParts {
  def forward(c: Char): Char

  def backward(c: Char): Char
}

case class Wire(setting:String) extends EnigmaParts {
  def forward(c: Char): Char = setting.charAt(c-'A')

  def backward(c: Char): Char = {
    def backrec(in:Int):Int={
      if(c==setting.charAt(in)) in
      else backrec(in+1)
    }
    ('A'+backrec(0)).toChar
  }
}

case class Rotor(rstate:Wire) extends EnigmaParts {
  def rotate():Wire={
    def turn():String={
      val nowstate:String=rstate.setting
      val f=nowstate.charAt(0)
      val rest=nowstate.substring(1)
      rest+f.toString
    }
    def shift(str:String):String={
      def shiftch(c:Char):Char={
        if(c-1<'A') (c-1+26).toChar
        else (c-1).toChar
      }

      val st=str.charAt(0)
      if(str.length==1){
        shiftch(st).toString
      }
      else{
        val next=str.substring(1)
        shiftch(st).toString+shift(next)
      }

    }
    new Wire(shift(turn()))

  }

  def forward(c: Char): Char = {
    rstate.forward(c)
  }

  def backward(c: Char): Char = {
    rstate.backward(c)
  }
}

case class Reflector(refset:Wire) extends EnigmaParts {
  def forward(c: Char): Char = {
    refset.forward(c)
  }

  def backward(c: Char): Char = {
    refset.backward(c)
  }
}

