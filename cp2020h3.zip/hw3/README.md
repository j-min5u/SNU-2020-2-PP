# Assignment 3: Programming Principles, SNU 4190.210

## Restrictions

1. Do not use keyword `var`. Use `val` and `def` instead.
2. You can use some classes in `scala.collections.*` (except `scala.collections.mutable.*`) and basic APIs in `String` and `Char` classes. You cannot use data structures in `scala.*` except primitive types (like `Int`, `Float`, ...), `Option`, and `Either`. Also you can make your custom case classes.

## Q&A

If you have any questions, please submit an issue to [pp202002 issue tracker](https://github.com/snu-sf-class/pp202002/issues).

## Submissions

HW3 submission page will be opened next week
http://147.46.242.53:21300





